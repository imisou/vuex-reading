# Concepts de base

Nous allons apprendre les concepts de base dans Vuex avec ce chapitre. Ces concepts sont
  - [État](state.md)
  - [Accesseurs](getters.md)
  - [Mutations](mutations.md)
  - [Actions](actions.md)
  - [Modules](modules.md)

Une compréhension profonde de ces concepts est essentielle pour l'utilisation de Vuex.

C'est parti.
